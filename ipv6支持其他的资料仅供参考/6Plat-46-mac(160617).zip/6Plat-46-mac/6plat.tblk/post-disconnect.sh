#!/bin/bash

cp /tmp/resolv.conf.org /etc/resolv.conf
