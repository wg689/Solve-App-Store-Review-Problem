//
//  AppDelegate.h
//  IP地址测试
//
//  Created by 张旭飞 on 16/6/6.
//  Copyright © 2016年 xf. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

