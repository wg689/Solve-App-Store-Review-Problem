//
//  main.m
//  IP地址测试
//
//  Created by 张旭飞 on 16/6/6.
//  Copyright © 2016年 xf. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
